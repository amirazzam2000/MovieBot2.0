create
    definer = root@localhost procedure CheckGrade(IN idStudent int, IN checkYear int, OUT status int)
begin
    IF not exists( select * from student where id = idStudent) then
        set status = 404;
    Elseif (select count(idSub) from Taken where idStu = idStudent and year = checkYear and grade >= 5)
               <  (select count(idSub)/2 from Taken where idStu = idStudent and year = checkYear) then
        set status = 418;
    else
        set status = 200;
    end if;
end;

