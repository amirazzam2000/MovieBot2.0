create definer = root@localhost trigger updateMovie
    after update
    on movie
    for each row
begin
        insert into
            auxUpdate(id_movie ,
                title ,
                id_director,
                year,
                duration,
                country ,
                movie_facebook_likes,
                imdb_score,
                gross,
                budget)
            values (
                OLD.id_movie,
                OLD.title,
                OLD.id_director,
                OLD.year,
                OLD.duration,
                OLD.country,
                OLD.movie_facebook_likes,
                OLD.imdb_score,
                OLD.gross,
                OLD.budget);
    end;

