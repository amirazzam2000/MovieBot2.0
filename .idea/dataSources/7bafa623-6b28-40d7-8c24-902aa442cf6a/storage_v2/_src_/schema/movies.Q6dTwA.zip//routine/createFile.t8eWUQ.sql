create
    definer = root@localhost procedure createFile()
begin

        set @q1 := concat('select \'new :\' , aadd.* from auxAdd aadd
                                union
                          select \'edit:\', up.* from auxUpdate up
                        into outfile \'C:/ProgramData/MySQL/MySQL Server 5.7/Uploads/' , curdate() , '.txt\' fields terminated by \';\'');
        prepare s1 from @q1;
        execute s1;deallocate prepare s1;


        delete from auxUpdate where title like'%%';
        delete from auxAdd where title like'%%';
    end;

