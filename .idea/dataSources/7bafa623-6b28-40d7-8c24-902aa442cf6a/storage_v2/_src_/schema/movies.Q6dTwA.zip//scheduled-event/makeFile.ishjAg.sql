create definer = root@localhost event makeFile on schedule
    every '1' DAY
        starts '2020-04-03 11:30:00'
    enable
    do
    begin
            call createFile();
        end;

