create definer = root@localhost view worst_movies as
select `movies`.`movie`.`title`           AS `title`,
       `movies`.`movie`.`year`            AS `year`,
       `movies`.`movie`.`country`         AS `country`,
       `movies`.`movie`.`imdb_score`      AS `imdb_score`,
       count(distinct `pm`.`id_producer`) AS `count(distinct id_producer)`
from (`movies`.`movie`
         join `movies`.`producer_movie` `pm` on ((`movies`.`movie`.`id_movie` = `pm`.`id_movie`)))
where (`movies`.`movie`.`imdb_score` = 0)
group by `movies`.`movie`.`id_movie`;

