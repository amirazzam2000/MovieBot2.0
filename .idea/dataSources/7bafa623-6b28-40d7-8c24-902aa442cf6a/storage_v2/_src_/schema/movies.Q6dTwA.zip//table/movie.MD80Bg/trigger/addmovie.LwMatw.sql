create definer = root@localhost trigger addMovie
    after insert
    on movie
    for each row
begin
        insert into
            auxAdd(id_movie ,
                title ,
                id_director,
                year,
                duration,
                country ,
                movie_facebook_likes,
                imdb_score,
                gross,
                budget)
            values (
                NEW.id_movie,
                NEW.title,
                NEW.id_director,
                New.year,
                NEW.duration,
                New.country,
                NEW.movie_facebook_likes,
                NEW.imdb_score,
                NEW.gross,
                NEW.budget);
    end;

